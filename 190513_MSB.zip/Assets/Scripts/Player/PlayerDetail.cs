﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDetail : MonoBehaviour
{
    User controller;

    public User Controller
    {
        get
        {
            return controller;
        }

        set
        {
            controller = value;
        }
    }

    void Start()
    {
        
    }
    
}
